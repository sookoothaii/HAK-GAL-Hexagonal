
# LLM Collaboration Mini Evaluation Kit

This bundle provides:
- A tiny **corpus** (`corpus/D001..D003.txt` and `corpus_index.json`, with character spans per sentence).
- Three **tasks** (`tasks/tasks.json`).
- A **gold ledger** with claim-level labels and evidence spans (`gold/gold_ledger.jsonl`).
- Prompt templates for **Author**, **Blind Reviewer**, and **Meta Reviewer** (`prompts/*.txt`).
- A simple **evaluator** computing ASR, HR, and ECE (`scoring/evaluator.py`).

## Ledger format expected by the evaluator
Each prediction row must contain:
```json
{
  "task_id": "T001",
  "claim_id": "T001-C01",
  "label": "supported|refuted|unverifiable|abstain",
  "confidence": 0.73,
  "evidence": [{"doc_id":"D001","start":0,"end":120}]
}
```
- Evidence spans are **character offsets** in the corresponding `corpus/Dxxx.txt` file.
- You can produce ledgers for **author** or **meta**; both are acceptable to the scorer.

## Run the scorer
```
python scoring/evaluator.py --gold gold/gold_ledger.jsonl --pred <your_model_ledger.jsonl>
```

### Metrics
- **ASR** (Attributable Support Rate): fraction of all claims that are both labeled *supported* and backed by overlapping evidence spans in the gold ledger.
- **HR** (Hallucination Rate): fraction of all claims where the model asserted support/refutation without adequate evidence (or contradicted gold).
- **ECE** (Expected Calibration Error): 10-bin ECE comparing confidence vs. empirical correctness.

> Reproducibility: run the same setup multiple times (pinned parameters) and compare ledgers to compute exact-match or Cohen’s κ externally.

## Notes
- This is a *minimal* kit for quick bring-up; expand the corpus, tasks, and adjudication process for serious studies.
- For collaboration modes (blind review, meta-review), evaluate the **final** ledger.
