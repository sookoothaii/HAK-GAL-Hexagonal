
import json, argparse, math, os
from collections import defaultdict

LABELS = ["supported", "refuted", "unverifiable", "abstain"]

def load_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows

def iou(span_a, span_b):
    # simple 1D IoU on character offsets
    a0, a1 = span_a
    b0, b1 = span_b
    inter = max(0, min(a1, b1) - max(a0, b0))
    union = max(a1, b1) - min(a0, b0)
    return inter / union if union > 0 else 0.0

def evidence_matches(pred_evs, gold_evs, iou_thresh=0.2):
    # True if any pred span overlaps (IoU) any gold span on same doc_id
    for pe in pred_evs:
        for ge in gold_evs:
            if pe["doc_id"] == ge["doc_id"]:
                if iou((pe["start"], pe["end"]), (ge["start"], ge["end"])) >= iou_thresh:
                    return True
    return False

def bin_confidence(c):
    # 10 uniform bins
    b = int(min(9, max(0, math.floor(c * 10))))
    lo = b/10.0
    hi = (b+1)/10.0
    return b, lo, hi

def compute_metrics(gold_rows, pred_rows, verbose=False):
    gold_map = {(r["task_id"], r["claim_id"]): r for r in gold_rows}
    # Expect pred_rows as list of entries with keys: task_id, claim_id, label, confidence, evidence[]
    n = 0
    correct_supported = 0
    hallucinations = 0
    supported_preds = 0

    # For ECE: collect per-claim confidences and correctness (1/0)
    ece_bins = [ {"sum_conf":0.0, "sum_acc":0.0, "count":0} for _ in range(10) ]

    # For RS: you need to run this script twice and compare ledgers externally,
    # or feed two prediction files via CLI; here we compute only single-run stats.
    for p in pred_rows:
        key = (p["task_id"], p["claim_id"])
        if key not in gold_map:
            continue
        g = gold_map[key]
        n += 1
        label_pred = p.get("label", "").lower()
        conf = float(p.get("confidence", 0.0))
        evidence_pred = p.get("evidence", [])

        # correctness at claim level (coarse): match of label + evidence when needed
        is_correct = 0
        if g["label"] == "supported":
            if label_pred == "supported":
                supported_preds += 1
                if evidence_matches(evidence_pred, g["evidence"]):
                    is_correct = 1
                    correct_supported += 1
                else:
                    hallucinations += 1
            elif label_pred in ["refuted", "unverifiable", "abstain"]:
                # calling supported as refuted/unverifiable/abstain counts as incorrect but not hallucination
                pass
        elif g["label"] == "refuted":
            if label_pred == "refuted":
                if evidence_matches(evidence_pred, g["evidence"]):
                    is_correct = 1
                else:
                    hallucinations += 1
            elif label_pred == "supported":
                hallucinations += 1
        elif g["label"] == "unverifiable":
            if label_pred in ["unverifiable", "abstain"]:
                is_correct = 1
            elif label_pred in ["supported", "refuted"]:
                hallucinations += 1

        # ECE binning
        b, lo, hi = bin_confidence(conf)
        ece_bins[b]["sum_conf"] += conf
        ece_bins[b]["sum_acc"] += is_correct
        ece_bins[b]["count"] += 1

    # Metrics
    total_claims = n if n > 0 else 1
    ASR = correct_supported / total_claims
    HR = hallucinations / total_claims

    # ECE: expected calibration error over occupied bins
    ece = 0.0
    total = 0
    for b in range(10):
        c = ece_bins[b]["count"]
        if c == 0:
            continue
        avg_conf = ece_bins[b]["sum_conf"] / c
        avg_acc = ece_bins[b]["sum_acc"] / c
        ece += (c / total_claims) * abs(avg_conf - avg_acc)
        total += c

    return {"ASR": ASR, "HR": HR, "ECE": ece, "count_claims": total_claims}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gold", required=True, help="Path to gold_ledger.jsonl")
    ap.add_argument("--pred", required=True, help="Path to model ledger JSONL (author or meta)")
    args = ap.parse_args()

    gold_rows = load_jsonl(args.gold)
    pred_rows = load_jsonl(args.pred)
    metrics = compute_metrics(gold_rows, pred_rows)
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
